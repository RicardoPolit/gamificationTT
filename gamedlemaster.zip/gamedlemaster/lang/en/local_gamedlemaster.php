<?php
/*
 * UNIVERSITY:  INSTITUTO POLITECNICO NACIONAL (IPN)
 *              ESCUELA SUPERIOR DE COMPUTO (ESCOM)
 *   SUBJECT:     _
 *   PROFESSOR:   _
 *
 * DESARROLLADORES: Daniel Ortega
 *
 * PRACTICE _:  TITULO DE LA PRACTICA
 *               - DESCRIPCION
 *
*/

/* GENERAL STRINGS */
$string['pluginname'] = 'Gamedle Master';
$string['gmxp'] = 'Gamedle Master'; // TODO INCORRECT STRING ENTRY

// FORM STRING MESSAGES
$string['FORM_SUCCESS'] = 'Configurations updated successfully';
$string['FORM_ERROR'] = 'There are incorrect values';
