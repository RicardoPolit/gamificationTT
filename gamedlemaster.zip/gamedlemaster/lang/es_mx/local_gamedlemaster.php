<?php
/*
 * UNIVERSITY:  INSTITUTO POLITECNICO NACIONAL (IPN)
 *              ESCUELA SUPERIOR DE COMPUTO (ESCOM)
 *   SUBJECT:     _
 *   PROFESSOR:   _
 *
 * DESARROLLADORES: Daniel Ortega
 *
 * PRACTICE _:  TITULO DE LA PRACTICA
 *               - DESCRIPCION
 *
*/

/* GENERAL STRINGS */
$string['pluginname'] = 'Gamedle Master';
$string['gmxp'] = 'Gamedle Master';

// FORM STRING MESSAGES
$string['FORM_SUCCESS'] = 'Configuraciones actualizadas exitosamente';
